<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <title>DeepDiveExpo</title>

    <link rel="icon" href="https://i.pinimg.com/originals/88/33/f2/8833f2811794959bdcc2433a512a7bac.png"
        type="image/png">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <style>
     /* Reset CSS */
     * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    html, body {
    height: 100%;
    margin: 0;
    padding: 0;
}
    body {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        background-color: #C1E8FF;
        color: #333;
        flex-wrap: wrap;
    }
    
        /* Header */
        header {
            background: #052659;
            position: fixed;
            /* يجعل الهيدر ثابتًا في أعلى الصفحة */
            width: 100%;
            /* يجعل عرض الهيدر يمتد على عرض الصفحة بالكامل */
            z-index: 1000;
            /* يضمن أن يكون الهيدر فوق جميع العناصر الأخرى */
            padding: 5px 0;
            top: 0;
            /* يحدد المسافة من أعلى الصفحة */
            left: 0;
            /* يحدد المسافة من الجانب الأيسر للصفحة */
        }


        .logo img {
            max-width: 50px;
            height: auto;
            margin-right: 0px;
        }

        nav {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 95%;
            margin: auto;
        }

        .nav-links {
            list-style: none;
            display: flex;
            justify-content: center;
            flex-grow: 1;
        }

        .nav-links li {
            position: relative;
        }

        .nav-links a {
            text-decoration: none;
            color: #C1E8FF;
            font-size: 20px;
            padding: 10px 40px;
            margin-right: 30px;
            transition: background 0.3s ease;
        }

        .nav-links a:hover {
            background: #00b4d8;
            border-radius: 30px;
        }

        /*-----------------------------------------------gallery-------------------------------------------------------------- */
        .gallery {
            width: 90%;
            margin: 30px auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            grid-gap: 20px;
        }


        .gallery img:hover {
            transform: scale(1.05);
        }

        /* التعديل في CSS */
        .gallery img {
            width: 100%;
            height: 200px;
            /* كل الصور ستكون بارتفاع 200 بكسل */
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, top 0.3s ease, border-radius 0.3s ease;
            /* إضافة انتقال لتنعيم الحواف */
            cursor: pointer;
            object-fit: cover;
        }

        .gallery img.active {
            position: fixed;
            top: 50%;
            left: 50%;
            width: auto;
            /* عرض الصورة عند التكبير */
            height: auto;
            /* ضبط الارتفاع تلقائياً ليحافظ على النسبة */
            transform: translate(-50%, -50%) scale(1);
            /* تكبير الصورة وتوسيطها */
            z-index: 1000;
            box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.3);
            border-radius: 15px;
            /* تنعيم الحواف عند التكبير */
            transition: transform 0.3s ease, width 0.3s ease, border-radius 0.3s ease;
            /* تأكيد الانتقال بسلاسة */
        }


        /*-----------------------------------------------footer-------------------------------------------------------------- */
/*-------------------------------------------------------------------------------------------------------------------- */
footer {
            background: #021024;
            color: #C1E8FF;
            padding: 20px 0;
        }

        footer .container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            width: 80%;
            margin: auto;
            gap: 20px;
        }

        footer h3 {
            margin-bottom: 20px;
            font-size: 20px;
        }

        .contact ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .menu-links ul {
            list-style: none;
        }

        .contact li, .menu-links li {
            margin-bottom: 10px;
            font-size: 12px;
        }

        .contact a {
            color: #fff;
            text-decoration: none;
        }

        .contact a:hover {
            text-decoration: underline;
        }

        .menu-links {
            width: 100%;
        }

        .menu-links ul {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .menu-links a {
            display: block;
            padding: 10px;
            color: #C1E8FF;
            text-decoration: none;
            text-align: center;
        }

        .menu-links a:hover {
            background: #00b4d8;
        }

/*-------------------------------------------------------------------------------------------------------------------- */

    </style>
</head>

<body>

    <div class="site-mobile-menu">
        <div class="site-mobile-menu-header">
            <div class="site-mobile-menu-close mt-3">
                <span class="icon-close2 js-menu-toggle"></span>
            </div>
        </div>
        <div class="site-mobile-menu-body"></div>
    </div>

    <header class="site-navbar position-sticky" role="banner">

        <div class="container">
            <div class="row align-items-center">

                <div class="col-11 col-xl-2">
                    <a href="index.php">
                        <div class="logo">
                            <img src="https://i.pinimg.com/originals/88/33/f2/8833f2811794959bdcc2433a512a7bac.png"
                                alt="Dive Club Logo">
                        </div>
                    </a>
                </div>
                <div class="col-12 col-md-10 d-none d-xl-block">
                    <nav class="site-navigation position-relative text-right" role="navigation">

                        <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
                            <li><a href="index.php"><span>Home</span></a></li>
                            <li> <a href="booking.php"><span>booking</span></a></li>
                            <li><a href="about.php"><span>About</span></a></li>
                            <li><a href="contact.php"><span>Contact</span></a></li>
                        </ul>
                    </nav>
                </div>
                <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a
                        href="#" class="site-menu-toggle js-menu-toggle text-white"><span
                            class="icon-menu h3"></span></a></div>
            </div>
        </div>
        </div>
    </header>

    <br><br><br>
    <!-- Gallery Section -->
    <section class="gallery">
        <img src="https://i.pinimg.com/564x/a7/5f/86/a75f8694d45f48d5535ec52c08794d35.jpg" alt="Gallery Image 1"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/57/c5/cf/57c5cfe9e13e3dff4ef9ac0fbe980929.jpg" alt="Gallery Image 2"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/736x/56/c7/7d/56c77d0abe3365a2e45afca056fa622e.jpg" alt="Gallery Image 3"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/dd/74/86/dd7486973c58325107bed97165d1fab8.jpg" alt="Gallery Image 4"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/d9/94/96/d994963a233557996fe081ec0fd8a9ca.jpg" alt="Gallery Image 5"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/ca/c6/f8/cac6f8a6a4e492fe37653f385f0e11cb.jpg" alt="Gallery Image 6"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/a7/5f/86/a75f8694d45f48d5535ec52c08794d35.jpg" alt="Gallery Image 1"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/57/c5/cf/57c5cfe9e13e3dff4ef9ac0fbe980929.jpg" alt="Gallery Image 2"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/736x/56/c7/7d/56c77d0abe3365a2e45afca056fa622e.jpg" alt="Gallery Image 3"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/dd/74/86/dd7486973c58325107bed97165d1fab8.jpg" alt="Gallery Image 4"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/d9/94/96/d994963a233557996fe081ec0fd8a9ca.jpg" alt="Gallery Image 5"
            onclick="openModal(this)">
        <img src="https://i.pinimg.com/564x/ca/c6/f8/cac6f8a6a4e492fe37653f385f0e11cb.jpg" alt="Gallery Image 6"
            onclick="openModal(this)">


    </section>

    <!-- The Modal -->
    <div id="myModal" class="modal">
        <span class="close" onclick="closeModal()">&times;</span>
        <img class="modal-content" id="img01">
    </div>

    <!-- footer -->
    <footer>
        <div class="container">
            <div class="contact">
                <h3>Contact Us</h3>
                <ul class="contact-list">
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> Address</li>
                    <li><i class="fa fa-mobile" aria-hidden="true"></i> +962 0787139731</li>
                    <li><i class="fa fa-envelope" aria-hidden="true"></i>
                        <a href="mailto:celestialsailors9@gmail.com">celestialsailors9@gmail.com</a>
                    </li>
                </ul>
            </div>
            <div class="menu-links">
                <h3>Menu Links</h3>
                <ul class="link-menu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="booking.php">Booking</a></li>                 
                     <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </footer>
    <!-- end footer -->

    <!-- JavaScript -->

    <script>
        // Select all images in the gallery
        const images = document.querySelectorAll('.gallery img');

        // Add event listener to each image
        images.forEach(image => {
            image.addEventListener('click', () => {
                // Check if this image is already active
                if (image.classList.contains('active')) {
                    // Remove 'active' class to shrink the image
                    image.classList.remove('active');
                } else {
                    // Remove 'active' class from any currently active image
                    document.querySelector('.gallery img.active')?.classList.remove('active');

                    // Add 'active' class to the clicked image
                    image.classList.add('active');
                }
            });
        });
    </script>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/main.js"></script>
</body>

</html>