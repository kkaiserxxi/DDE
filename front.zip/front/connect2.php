<?php

$FullName = $_POST['FullName'];
$email = $_POST['email'];
$message = $_POST['message'];

//Database connection
$conn = new mysqli('localhost', 'MSI', 'msi12', 'deepdiveexpo');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
} else {
    // Step 1: Check if the user already exists in the 'user' table
    $stmt = $conn->prepare("SELECT user_id FROM user WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        // User exists, fetch their user_id
        $stmt->bind_result($user_id);
        $stmt->fetch();
    } else {
        // Step 2: Insert new user into the 'user' table
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO user (FullName, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $FullName, $email);
        $stmt->execute();
        
        // Get the user_id of the newly inserted user
        $user_id = $conn->insert_id;
    }
    
    $stmt->close();

    // Step 3: Insert booking details into the 'booking' table using the user_id
    $stmt = $conn->prepare("INSERT INTO booking (user_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $message);
    $stmt->execute();

    echo "contactus successfully created";
    
    $stmt->close();
    $conn->close();
}

?>
